﻿namespace IceCore.Models
{
    public class Sub {
        public static string? name { get; set; }
        public static string? password { get; set; }
    }
}
